# 2019 CAI Shared Task
In this study, a model was designed for the 2019 COGAI shared task challenge. The purpose of this challenge was to develop a robust and innovative multiclass classification model that could predict the job domain of a job on the basis of its description. The final model consisted of a TF-IDF vectorizer and a linear SVC, and yielded an F-score score of .77 on the test set.
